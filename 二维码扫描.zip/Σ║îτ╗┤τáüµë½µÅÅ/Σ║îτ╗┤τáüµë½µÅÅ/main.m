//
//  main.m
//  二维码扫描
//
//  Created by 安徽博瑞 on 2017/3/9.
//  Copyright © 2017年 个人资源. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
